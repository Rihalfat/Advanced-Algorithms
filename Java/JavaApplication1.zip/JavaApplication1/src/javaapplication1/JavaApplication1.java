package javaapplication1;

public class JavaApplication1 {

    public static void main(String[] args) 
    {
        double twosets[] = new double[40];
        int i, j;
        
        for (i=0; i<20; i++)
        {
            twosets[i] = i*i;
        }
        for (i=20; i<40; i++)
        {
            twosets[i] = i/2.0;
        }
        
        i=0;
        while(i<40)
        {
            for(j=1; j<=10; j++)
            {
                System.out.print(twosets[i] + " ");
                i++;
            }
            System.out.println();
        }
    }
    
}
